﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stu.Exception
{
    public class StudentException: ApplicationException
    {
        //Default Constructor
        public StudentException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public StudentException(string message)
            : base(message)
        { }
    }
    
}
