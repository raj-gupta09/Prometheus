﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Prometheus_Student
{
    /// <summary>
    /// Interaction logic for StudentHomework.xaml
    /// </summary>
    public partial class StudentHomework : Window
    {
        public StudentHomework()
        {
        }

        public StudentHomework(String StudentID)
        {


            InitializeComponent();
            SqlConnection empConnObj = null;
            SqlConnection ConnObj = null;
            SqlDataReader empReader = null;
            SqlDataReader cmdReader = null;
            DataTable dt = new DataTable();
            DataTable dt2 = new DataTable();
            string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
            try
            {
                empConnObj = new SqlConnection();
                empConnObj.ConnectionString = empConnStr;
                SqlCommand empCommand = new SqlCommand("SELECT Homework.HomeworkID , Homework.HomeworkName FROM  Group1.Homework INNER JOIN Group1.Course ON Student.CourseID = Course.CourseID" , empConnObj);
                empCommand.Parameters.AddWithValue("@Homework.Description",StudentID);
                empConnObj.Open();

                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dt.Load(empReader);
                }
                foreach (DataRow row in dt.Rows)
                {
                    //Console.WriteLine(row["ImagePath"]);
                    comboBox.Items.Add(row["Description"]);
                }
                comboBox.SelectedIndex = 0;
                ConnObj = new SqlConnection();
                ConnObj.ConnectionString = empConnStr;
                SqlCommand cmd = new SqlCommand("SELECT * from Group1.Student", ConnObj);
                ConnObj.Open();

                cmdReader = cmd.ExecuteReader();
                if (cmdReader.HasRows)
                {
                    dt2.Load(cmdReader);
                }
                foreach (DataRow row2 in dt2.Rows)
                {
                    LeftListBox.Items.Add(row2["FName"]);
                }
                LeftListBox.SelectAll();
                //for (int i = 0; i < listBox.Items.Count; i++)
                //{
                //    listBox.SetSelected(i,true);
                //}

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open)
                    empConnObj.Close();
            }
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            List<ListItem> list = new List<ListItem>();
            foreach (ListItem item in LeftListBox.Items)
            {
                list.Add(item);

                RightListBox.Items.Add(item);
            }
            foreach (ListItem item in list)
            {
                LeftListBox.Items.Remove(item);
            }
        }

        private void LeftListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}