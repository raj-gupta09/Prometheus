﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Prometheus_Student
{
    public partial class Student_Planning : Form
    {
        public Student_Planning()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        void fillListBox()

        {

            string str = " Source = ndamssql/sqlilearn; Initial catalog = Sep19CHN; User ID = sqluser; Password = sqluser";

            SqlConnection con = new SqlConnection(str);

            string query = "select * from Group1.Homework";

            SqlCommand cmd = new SqlCommand(query, con);

            SqlDataReader dbr;

            try

            {

                con.Open();

                dbr = cmd.ExecuteReader();

                while (dbr.Read())

                {

                    //string sname = (string)myreader["name"]; ; //name is coming from database

                    //listBox1.Items.Add(sname);

                }

            }

            catch (Exception es)

            {

                MessageBox.Show(es.Message);

            }

        }
    }
}
