﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Stu.Entity;
using Stu.Exception;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Stu.DAL
{
    public class StudentOperation
    {
        SqlConnection ConnObj = null;
        SqlCommand Command = DataConnection.GenerateCommand();
        DataTable dt = new DataTable();
        string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();

        public int updateStudent_DAL(Student stud)
        {
            int rowAffected = 0;
            try
            {
                Command.Parameters.AddWithValue("@StudentID", stud.StudentID);
                Command.Parameters.AddWithValue("@FName", stud.FName);
                Command.Parameters.AddWithValue("@LName", stud.LName);
                Command.Parameters.AddWithValue("@Address", stud.Address);
                Command.Parameters.AddWithValue("@DOB", stud.DOB);
                Command.Parameters.AddWithValue("@city", stud.City);
                Command.Parameters.AddWithValue("@MobileNo", stud.MobileNo);
                Command.Parameters.AddWithValue("@Password", stud.Password);

                Command.Connection.Open();
                rowAffected = Command.ExecuteNonQuery();
                Command.Connection.Close();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (StudentException)
            {

                throw;
            }
            //finally
            //{
            //    if (ConnObj.State == ConnectionState.Open)

            //    { ConnObj.Close(); }
            //}

            return rowAffected;
        }

      
    }
}















        
       



              
               
      
